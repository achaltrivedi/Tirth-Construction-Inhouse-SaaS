--
-- PostgreSQL database dump
--

\restrict yNkJmmpWc46Qk5OMcpOLSSyf42pY58Qf3fNS6GVqnFCFYYgLADZmigPRT5bEqQK

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Attendance; Type: TABLE; Schema: public; Owner: cols_user
--

CREATE TABLE public."Attendance" (
    id text NOT NULL,
    "workerId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    status text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Attendance" OWNER TO cols_user;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: cols_user
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "transactionId" text,
    action text NOT NULL,
    "oldValue" text,
    "newValue" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO cols_user;

--
-- Name: Site; Type: TABLE; Schema: public; Owner: cols_user
--

CREATE TABLE public."Site" (
    id text NOT NULL,
    name text NOT NULL,
    "clientName" text NOT NULL,
    "projectType" text NOT NULL,
    "contractValue" double precision,
    "startDate" timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Site" OWNER TO cols_user;

--
-- Name: Transaction; Type: TABLE; Schema: public; Owner: cols_user
--

CREATE TABLE public."Transaction" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    description text NOT NULL,
    "cashIn" double precision DEFAULT 0 NOT NULL,
    "cashOut" double precision DEFAULT 0 NOT NULL,
    "netValue" double precision DEFAULT 0 NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Transaction" OWNER TO cols_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: cols_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    role text DEFAULT 'operator'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO cols_user;

--
-- Name: Worker; Type: TABLE; Schema: public; Owner: cols_user
--

CREATE TABLE public."Worker" (
    id text NOT NULL,
    name text NOT NULL,
    phone text,
    "siteId" text NOT NULL,
    wage double precision,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Worker" OWNER TO cols_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: cols_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO cols_user;

--
-- Data for Name: Attendance; Type: TABLE DATA; Schema: public; Owner: cols_user
--

COPY public."Attendance" (id, "workerId", date, status, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: cols_user
--

COPY public."AuditLog" (id, "userId", "transactionId", action, "oldValue", "newValue", "createdAt") FROM stdin;
\.


--
-- Data for Name: Site; Type: TABLE DATA; Schema: public; Owner: cols_user
--

COPY public."Site" (id, name, "clientName", "projectType", "contractValue", "startDate", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Transaction; Type: TABLE DATA; Schema: public; Owner: cols_user
--

COPY public."Transaction" (id, "siteId", date, description, "cashIn", "cashOut", "netValue", "isDeleted", "deletedAt", "deletedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: cols_user
--

COPY public."User" (id, name, email, password, role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Worker; Type: TABLE DATA; Schema: public; Owner: cols_user
--

COPY public."Worker" (id, name, phone, "siteId", wage, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: cols_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
879a5fae-ac55-4150-9e8a-482e3c01df15	59f1f6c2dad0960e312f0722f891301c879449be5b72cca7b69b41e7709bb462	2026-03-06 10:50:48.894277+00	20260306105048_init	\N	\N	2026-03-06 10:50:48.61373+00	1
\.


--
-- Name: Attendance Attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."Attendance"
    ADD CONSTRAINT "Attendance_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Site Site_pkey; Type: CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_pkey" PRIMARY KEY (id);


--
-- Name: Transaction Transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Worker Worker_pkey; Type: CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Attendance_createdAt_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Attendance_createdAt_idx" ON public."Attendance" USING btree ("createdAt");


--
-- Name: Attendance_date_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Attendance_date_idx" ON public."Attendance" USING btree (date);


--
-- Name: Attendance_workerId_date_key; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE UNIQUE INDEX "Attendance_workerId_date_key" ON public."Attendance" USING btree ("workerId", date);


--
-- Name: Attendance_workerId_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Attendance_workerId_idx" ON public."Attendance" USING btree ("workerId");


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_transactionId_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "AuditLog_transactionId_idx" ON public."AuditLog" USING btree ("transactionId");


--
-- Name: AuditLog_userId_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "AuditLog_userId_idx" ON public."AuditLog" USING btree ("userId");


--
-- Name: Site_createdAt_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Site_createdAt_idx" ON public."Site" USING btree ("createdAt");


--
-- Name: Site_status_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Site_status_idx" ON public."Site" USING btree (status);


--
-- Name: Transaction_createdAt_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Transaction_createdAt_idx" ON public."Transaction" USING btree ("createdAt");


--
-- Name: Transaction_date_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Transaction_date_idx" ON public."Transaction" USING btree (date);


--
-- Name: Transaction_isDeleted_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Transaction_isDeleted_idx" ON public."Transaction" USING btree ("isDeleted");


--
-- Name: Transaction_siteId_date_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Transaction_siteId_date_idx" ON public."Transaction" USING btree ("siteId", date);


--
-- Name: Transaction_siteId_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Transaction_siteId_idx" ON public."Transaction" USING btree ("siteId");


--
-- Name: User_createdAt_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "User_createdAt_idx" ON public."User" USING btree ("createdAt");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Worker_createdAt_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Worker_createdAt_idx" ON public."Worker" USING btree ("createdAt");


--
-- Name: Worker_isActive_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Worker_isActive_idx" ON public."Worker" USING btree ("isActive");


--
-- Name: Worker_siteId_idx; Type: INDEX; Schema: public; Owner: cols_user
--

CREATE INDEX "Worker_siteId_idx" ON public."Worker" USING btree ("siteId");


--
-- Name: Attendance Attendance_workerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."Attendance"
    ADD CONSTRAINT "Attendance_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES public."Worker"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public."Transaction"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Transaction Transaction_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Worker Worker_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cols_user
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict yNkJmmpWc46Qk5OMcpOLSSyf42pY58Qf3fNS6GVqnFCFYYgLADZmigPRT5bEqQK

